# VAM — Corrección de recibos en el portal de propietarios

**Estado:** código preparado; NO instalado ni desplegado. Requiere revisión, prueba y commit.

## Archivo nuevo (ruta exacta)

Copia `route.ts` a:

`app/api/propietarios/soportes-gastos/route.ts`

Crea las carpetas si no existen. `SUPABASE_SERVICE_ROLE_KEY` debe estar en el entorno de servidor, NUNCA en NEXT_PUBLIC ni en el navegador.

## Archivo existente a editar

`app/movil/propietarios/resumen-financiero/page.tsx`

1. Reemplaza completamente el método `cargarSoportesPropietario(gastosBase: Gasto[])` por el contenido de `nuevo_metodo.ts.txt`.
2. Cambia únicamente la invocación:
   `const gastosConSoportes = await cargarSoportesPropietario(gastosBase);`
   por:
   `const gastosConSoportes = await cargarSoportesPropietario(gastosBase, s, p);`
3. Elimina las definiciones que ya no se usan en la página: `DocumentoGastoPropietario`, `BUCKET_DOCUMENTOS`, `TIPOS_RECIBO`, `TIPOS_SOPORTE_PROPIETARIO` y la función `resolverUrlDocumento`. Conserva `esUrlPublica`.

## Validaciones requeridas antes de desplegar

- `npm run build` en local; revisar errores de TypeScript.
- Propietario autorizado, sesión de incógnito, período cerrado de julio de 2026: gasto 125 debe mostrar Comprobante y Recibo.
- Sin token, token vencido y token de otro condominio: respuesta 401/403 y ningún documento.
- Mes no cerrado: respuesta 403.
- Verificar que los enlaces caducan tras 10 minutos y el refresco renueva su vigencia.
- Revisar seguridad: los recibos activos históricos con `visible_propietarios=false` se incluyen deliberadamente por compatibilidad. Las facturas y los cheques exigen `visible_propietarios=true`.

No se modifica ninguna política RLS ni se hace público el bucket. El endpoint comprueba token, unidad, condominio, cierre e integridad de client_id antes de firmar rutas existentes de Storage.

Nota: la URL firmada dura 600 segundos. Si el usuario deja abierta la pantalla más tiempo, debe actualizarla para renovar los enlaces.
